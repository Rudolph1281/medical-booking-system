from django.apps import AppConfig


class BookingsystemConfig(AppConfig):
    name = 'BookingSystem'
