from django.shortcuts import render
from django.http import HttpResponse
from .models import*
from datetime import *
import datetime
#from django.contrib.auth.decorators import login_required


todaysDate = datetime.date.today() 

#Direct site to first page (login)
def homePage(request):
    return render(request,'login.html')

#Handle input from login page
def candidateChecker(request):
    email = request.POST['email']
    pword = request.POST['psw']

    currentCandidate = verifyCandidate(email)
    #If user does not exist in system, suggest sign up
    if currentCandidate is None:
        return render(request,'login.html',
            {'message':'Username does not exist, please try again.'}) 
    else:
        #Successful login details sends user to next page (Ts and Cs page)
        if currentCandidate.password==pword:
            return render(request,'termsNconditions.html', 
                {"email":currentCandidate.email_address})    
        else:
            return render(request,'login.html',
            {'message':'Incorrect password entered, please try again'})


#Direct site to sign up page (Registration) 
def signUpPage(request):
    return render(request,'signup.html')

#Handle input from sign up page
def signUp(request):
    userList = populateUsers_Passwords()
    fullName=request.POST['full_name']
    email=request.POST['email']
    idNumber=request.POST['idNumber']
    pword=request.POST['psw']
    pword2=request.POST['psw2']
    #Check if username already exists in the system (avoid duplication)
    if email in userList[0]:
        return render(request,'signup.html',
        {'message':'Username already exists, please select another','error':' to sign in.'})
    #Check if passwords entered match
    if (pword!=pword2):
        return render(request,'signup.html',
        {'message':'Make sure to enter the same password again.'})
    tempCandidate = Candidate(name_and_Surname=fullName,email_address=email,password=pword,idNumber=idNumber)
    tempCandidate.save()
    userList = populateUsers_Passwords()
    #After successful registeration, redirect to login page
    return render(request,'login.html',
        {"candidate":tempCandidate})
  
  
#Check if user checked the terms and conditions and redirects to the 
#risk assessment form
def termsNconditionsHandler(request):
    #cUser = populateUsers_Passwords()
    username = request.POST['candidate']
    return render(request,'risk-assessment.html', 
        {'email':username,'today':todaysDate})


#Handle all answers filled in on risk assessment form
#and depending on the RA score, the corresponding message is displayed
#with calendar 
def riskAssessmentFormInput(request):
    #all variable input from form
    #eg. transport=yes or no
    email=request.POST['candidate']
    user = verifyCandidate(email)
    
    
    nameNsname = request.POST['nameNsname']
    companyName = request.POST['companyName']
    address = request.POST['residentialAddress']
    idNumber = request.POST['IDnumber']
    transportToWork = request.POST['transport']
    
    localTravel = request.POST['localTravel']
    additionalLocalTravel = request.POST['localTravelAdditional']
    gatherings = request.POST['gatherings']
    patient = request.POST['patient']
    travelList = [localTravel,gatherings,patient]
    exposure = exposureCalc(transportToWork,travelList)
    
    cough = request.POST['cough']
    fever = request.POST['fever']
    soreThroat = request.POST['soreThroat']
    shortnessOfBreath = request.POST['shortnessOfBreath']
    lossOfSmell = request.POST['lossOfSmell']
    bodyPains = request.POST['bodyPains']
    lossOfTaste = request.POST['lossOfTaste']
    symptomsList = [cough,fever,soreThroat,shortnessOfBreath,lossOfSmell,bodyPains,lossOfTaste] 
    presentSymptoms=[]
    for s in symptomsList:
        if s=='Yes':
            presentSymptoms.append(s)
        else:
            continue
    symptoms = symptomsCalc(presentSymptoms)
    
    medicalConditions = request.POST['medicalConditions']
    household = request.POST['household']
    additionalMedicalConditions = request.POST['additionalMedicalConditions']
    additionalHousehold = request.POST['additionalHousehold']
    
    healthList = [medicalConditions, household]
    health = healthCalc(healthList)
    
    socialDistance = request.POST['socialDistance']
    mask = request.POST['mask']
    practise = request.POST['practise']
    hygieneList = [socialDistance, mask, practise]
    hygiene = hygieneCalc(hygieneList)
    
    vulnerability = (symptoms+health+hygiene)/3
    risk_assessment_score = exposure*vulnerability
    
    
    formAnswers = [nameNsname,idNumber,companyName,address,transportToWork,
        localTravel,additionalLocalTravel,gatherings,patient,
        cough,fever,soreThroat,lossOfSmell,shortnessOfBreath,bodyPains,lossOfTaste,
        medicalConditions,additionalMedicalConditions,household,additionalHousehold,
        socialDistance,mask,practise,risk_assessment_score]
    

    if len(presentSymptoms)>=2:
        ##FAIL VERY HIGH RISK
        riskFormDataHandler(user,formAnswers,'P')
        result = 'Welcome to Health Dynamics Bookings \
        Proceed Book for Your appointment. Rating: Have a Nice Day\
        Please Wear Your Musk When You Vist. Score = '+str(int(risk_assessment_score))
        return render(request,'book.html',
            {'email':email,'message':result,'today':todaysDate,'displayCalendar':True})
    
    if (patient=='Yes')or(medicalConditions=='Yes'):
        ##FAIL VERY HIGH RISK
        riskFormDataHandler(user,formAnswers,'P')
        result = 'Welcome to Health Dynamics Bookings \
        Proceed Book for Your appointment. Rating: Have a Nice Day\
        Please Wear Your Musk When You Vist. Score = '+str(int(risk_assessment_score))
        return render(request,'book.html',
            {'email':email,'message':result,'today':todaysDate,'displayCalendar':True})
    
    if (risk_assessment_score<7): ##PASS
        riskFormDataHandler(user,formAnswers,'P')
        message = 'Welcome to Health Dynamics Bookings \
            Please Wear Your Musk When You Vist. Score = '+str(int(risk_assessment_score))
        return render(request,'book.html',
                {'email':email,'message':message,'today':todaysDate,'displayCalendar':True})
    
    elif (risk_assessment_score<9): ## FAIL HIGH RISK
        riskFormDataHandler(user,formAnswers,'C')
        result = 'Welcome to Health Dynamics Bookings \
        Proceed Book for Your appointment. Rating: Have a Nice Day\
        Please Wear Your Musk When You Vist. Score = '+str(int(risk_assessment_score))
        return render(request,'book.html',
            {'email':email,'message':result,'today':todaysDate,'displayCalendar':True})
        
    else: ##FAIL VERY HIGH RISK
        riskFormDataHandler(user,formAnswers,'P')
        result = 'Welcome to Health Dynamics Bookings \
        Proceed Book for Your appointment. Rating: Have a Nice Day\
        Please Wear Your Musk When You Vist. Score = '+str(int(risk_assessment_score))
        return render(request,'book.html',
            {'email':email,'message':result,'today':todaysDate,'displayCalendar':True, 'candidates':candidates})
        


#Handles the 'Check availability' button
def bookingChecker(request):
    dateToCheck = request.POST['selectedDate']
    email = request.POST['candidate']
    datePart = dateToCheck.split('-')
    dateT= datetime.date(int(datePart[2]),int(datePart[1]),int(datePart[0]))
    
    user = verifyCandidate(email)
    venue = venueFinder(dateT)
    
    checked = checkDuplicateBooking(user,venue)
    if checked==True:
        message = 'You have already making a booking for the selected date:'+dateT.strftime('%A, %d %B %Y')
        return render(request,'book.html',
            {'selectedDate':dateT,'message':message ,'today':date.today(),
            'email':email,'displayCalendar':True})
    
    seatsTaken = getAvailableFromDate(dateT)
    seats = 30-seatsTaken
    if seatsTaken <=30:
        message='On '+dateT.strftime('%A, %d %B %Y') +' there are ' + str(seats)+ ' seats are available'
        return render(request,'book.html',
            {'selectedDate':dateToCheck,'message':message, 'today':date.today(),
            'email':email,'displayCalendar':True})
    else:
        message = 'No seats available'
        return render(request,'book.html',
            {'selectedDate':dateT,'message':message ,'today':date.today(),
            'email':email,'displayCalendar':True})
    


#Handles the 'Book now' button
def booking(request):
    email = request.POST['candidate']
    user = verifyCandidate(email)

    dateToBook = request.POST['selectedDate']
    datePart = dateToBook.split('-')
    dateT= datetime.date(int(datePart[2]),int(datePart[1]),int(datePart[0]))
    venue = venueFinder(dateT)
    
    bookingsForWeek = checkBookingsForWeek(dateT,user,venue)
    
    if bookingsForWeek<3:
        tempBooking = Booking(candidate=user,venue=venue)
        tempBooking.save()
        message='You have made a booking for '+ dateT.strftime('%A, %d %B %Y')+' have a good day'
        return render(request,'book.html', 
            {'mes':message,'email':email,'displayCalendar':True})
    else:
        return render(request,'book.html', 
            {'mes':'You have ran out of bookings for the week',
                'email':email,'displayCalendar':True})
    
 
def noCheckBook(request):
    dateToCheck = request.POST['selectedDate']
    email = request.POST['candidate']
    message = 'You first need to check if there are any bookings available, before making a booking'
    return render(request,'book.html',
            {'selectedDate':dateT,'message':message ,'today':date.today(),
            'email':email,'displayCalendar':True})
 

#Creates the risk form and saves it to the db
def riskFormDataHandler(u,a,s):
    newForm = RiskForm(candidate=u,
        mostRecentRiskForm=todaysDate,formStatus=s,
        name_and_Surname=a[0],idNumber=a[1],companyName=a[2], address=a[3],
        transportToWork=a[4],
        localTravel=a[5],localTravelExtra=a[6],gathering=a[7],patient=a[8],
        cough=a[9],fever=a[10],soreThroat=a[11],lossOfSmell=a[12],
        shortnessOfBreath=a[13],bodyPains=a[14],lossOfTaste=a[15],
        coMorbidities=a[16],coMorbiditiesExtra=a[17],
        household=a[18],householdExtra=a[19],
        socialDistance=a[20],mask=a[21],practise=a[22],
        RA_Score=a[23])
    newForm.save()



def exposureCalc(t,tList):
    tCon = 0
    lCon=0
    if t=='No':
        tCon=1 #Low
    else:
        tCon=3 #High
    
    if (tList[0]=='No' and tList[1]=='No' and tList[2]=='No'):
        lCon=0 #Low 
    
    elif (tList[0]=='Yes' and tList[1]=='Yes' and tList[2]=='Yes'):
        lCon=4 #Very High 
    
    elif (tList[0]=='No' and tList[2]=='No'):
        lCon=2 #Medium
    
    else:
        lCon=3 #High
    
    return (tCon+lCon)/2
    

def symptomsCalc(sList):
    numberOfSymptoms = len(sList)

    if numberOfSymptoms==0:
        return 1 #Low
    elif numberOfSymptoms<2:
        return 2 #Medium
    elif (numberOfSymptoms>=2):
        return 12 # High
    

def healthCalc(hList):
    #rating the answers regarding health conditions
    if (hList[0]=='No'):
        if (hList[1]=='No'): #no no
            return 1 #Low  
        else:             #no yes
            return 2 #Medium
    else:
        if (hList[1]=='No'): #yes no
            return 3 #High
        else:             #yes yes
            return 4 #Very High


def hygieneCalc(hList):
    if (hList[0]=='Yes'):
        if (hList[1]=='Yes'):
            if (hList[2]=='Yes'):
                return 1 #YYY
            else:
                return 2 #YYN
        else:
            if (hList[2]=='Yes'):
                return 3 #YNY
            else:
                return 3 #YNN
    else:
        if (hList[2]=='Yes'):
            if (hList[2]=='Yes'):
                return 2 #NYY
            else:
                return 3 #NYN
        else:
            if (hList[2]=='Yes'):
                return 3 #NNY
            else:
                return 4 #NNN
    

def userNames(cand):
    cList = []
    eList= []
    pList = []
    for i in cand:
        eList.append(i.email_address)
        eList.append(i.password)
    cList.append(eList)
    cList.append(pList)
    
    return cList


def dateMaker():
    #venues = Venue.objects.all()
    startDate = date(2020,6,22)
    currentDate = startDate
    endDate = startDate + timedelta(days=365)
    while currentDate<=endDate:
        if currentDate.weekday()<5:
            day = Venue(dayofTheWeek=currentDate)
            day.save()
            print('something happening?')
        currentDate+= timedelta(days=1)


def populateUsers_Passwords():
    existingCandidates = Candidate.objects.all()
    return userNames(existingCandidates)


def venueFinder(date):
    venues = Venue.objects.all()
    for v in venues:
        if date == v.dayofTheWeek:
            return v
    

def verifyCandidate(e_address): 
    existingCandidates = Candidate.objects.all()
    for x in existingCandidates:
        if x.email_address == e_address:
                return x
                

def checkBookingsForWeek(dateToCheck,c,venue):
    week = dateToCheck.isocalendar()[1]
    year = dateToCheck.year
    
    bookings = 0
    usersBookings = c.booking_set.all()
    if len(usersBookings)==0:
        return 0
    for booking in usersBookings:
        date = booking.venue.dayofTheWeek
        if (date.isocalendar()[1]==week) and (date.year==year):
            bookings+=1
    return bookings


def getAvailableFromDate(d):
    venues = Venue.objects.all()
    for v in venues:
        if v.dayofTheWeek==d:
            users = len(v.booking_set.select_related().all())
    return users
  
  
def checkDuplicateBooking(user,venue): 
    listOfBookings = Booking.objects.all()
    for booking in listOfBookings:
        if booking.candidate==user and booking.venue==venue:
            return True
    return False
 


