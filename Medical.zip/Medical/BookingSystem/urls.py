from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views

from BookingSystem import views


urlpatterns = [
    path('',views.homePage, name='loginPage'),
    path('login/',views.candidateChecker, name="login"),
    path('signup/',views.signUpPage, name="signupPage"),
    
    path('registerCandidate/' ,views.signUp, name="signUp"),
    path('signup/registerCandidate/' ,views.signUp, name="signUp"),
    
    path('tNc/',views.termsNconditionsHandler, name="tNc"),
    path('checker/tNc/',views.termsNconditionsHandler, name="tNc"),
    path('signup/registerCandidate/tNc/',views.termsNconditionsHandler, name="tNc"),
    
   
    path('riskForm/',views.riskAssessmentFormInput, name="riskForm"),
    
    path('riskForm/booking/',views.noCheckBook, name="noCheckBook"),
    
    
    path('verifyBooking/booking/',views.booking,name='booking'),
    path('riskForm/verifyBooking/' ,views.bookingChecker, name="verifyBooking"),
    path('verifyBooking/' ,views.bookingChecker, name="verifyBooking"),
    # path('checker/' ,views.CustomerChecker, name="checker"),

]