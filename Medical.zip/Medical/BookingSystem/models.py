from django.db import models
from django.utils import timezone
import datetime

    
class Candidate(models.Model):
    def __str__(self):
        return (self.name_and_Surname)
    
    candidate_id = models.AutoField(primary_key=True)
    name_and_Surname = models.CharField(max_length=100,default='Name and Surname')
    email_address = models.CharField(max_length=40,default='namesurname@gmail.com')
    password = models.CharField(max_length=20, default='password')
    idNumber = models.CharField('ID Number',max_length=30, default='000000 0000 000')
    
    
class Venue(models.Model):
    def __str__(self):
        return self.dayofTheWeek.strftime('%A, %d %B %Y')
 
    #venue_id = models.AutoField(primary_key=True)
    dayofTheWeek = models.DateField("Day to book", default=datetime.date(2020,6,22))
    max_seats = models.IntegerField(default=30)
    candidates = models.ManyToManyField(Candidate, through='Booking')
 
 
class Booking(models.Model):
    def __str__(self):
        return "%s %s" % (self.candidate.name_and_Surname, self.venue.dayofTheWeek.strftime('%A, %d %B %Y'))

    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE)
    venue = models.ForeignKey(Venue, on_delete=models.CASCADE)
    
    
class RiskForm(models.Model):
    def __str__(self):
        return "%s : %s" % (self.candidate.name_and_Surname, self.mostRecentRiskForm.strftime('%A, %d %B %Y'))
     
    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE) 
        ##risk form information
    mostRecentRiskForm = models.DateField('Date of previous form', default=datetime.date.today)
    FORM_TYPES = ( ('P','P (Pass)'),('F','F (Fail)'),('C','C (Confirmation required)'))
    formStatus = models.CharField('Form Status',max_length=1, choices=FORM_TYPES, default='C')

    name_and_Surname = models.CharField(max_length=100,default='Name and Surname')
    idNumber = models.CharField('ID Number',max_length=50,default='000000 0000 000')
    companyName = models.CharField('Company Name',max_length=50,default='CapaCiTi')
    address = models.CharField('Address',max_length=50,default='Cape Town')
    transportToWork = models.CharField(max_length=20,default='Car')
    
    FORM_ANSWERS = ( ('Yes','Yes'),('No','No'))
    localTravel = models.CharField('Travelled locally?',max_length=3, choices=FORM_ANSWERS, default='No')
    localTravelExtra = models.CharField('Local travelling additional information', max_length=50, default='N/A')
    gathering = models.CharField('Attended any gatherings?',max_length=3, choices=FORM_ANSWERS, default='No')
    patient = models.CharField('In contact with COVID-19 patient?',max_length=3, choices=FORM_ANSWERS, default='No')
    
    cough =models.CharField('Cough?',max_length=3, choices=FORM_ANSWERS, default='No')
    fever =models.CharField('Fever?',max_length=3, choices=FORM_ANSWERS, default='No')
    soreThroat =models.CharField('Sore Throat?',max_length=3, choices=FORM_ANSWERS, default='No')
    lossOfSmell =models.CharField('Loss of smell?',max_length=3, choices=FORM_ANSWERS, default='No')
    shortnessOfBreath =models.CharField('Shortness of breath?',max_length=3, choices=FORM_ANSWERS, default='No')
    bodyPains =models.CharField('General body pains?',max_length=3, choices=FORM_ANSWERS, default='No')
    lossOfTaste =models.CharField('Loss of taste?',max_length=3, choices=FORM_ANSWERS, default='No')
    
    coMorbidities =models.CharField('Co-Morbidities?',max_length=3, choices=FORM_ANSWERS, default='No')
    coMorbiditiesExtra = models.CharField('Additional information', max_length=50, default='N/A')
    household =models.CharField('Co-Morbidities in household?',max_length=3, choices=FORM_ANSWERS, default='No')
    householdExtra = models.CharField('Additional information', max_length=50, default='N/A')
    
    socialDistance =models.CharField('Social distancing:',max_length=3, choices=FORM_ANSWERS, default='Yes')
    mask =models.CharField('Mask',max_length=3, choices=FORM_ANSWERS, default='Yes')
    practise =models.CharField('Practise safe hygiene',max_length=3, choices=FORM_ANSWERS, default='Yes')
    
    RA_Score = models.IntegerField('Risk Assessment Score',default=1)
   
        